# Launch your art on Bitcoin

## A simple template for launching your art on Bitcoin

It has everything you need to launch a new generative art collection on Bitcoin.

How to publish? See https://docs.generative.xyz/

Questions? Join our community https://discord.gg/ZkECdDPs

## Supported JS Libs

            [
                "p5js@1.5.0",
                "threejs@r124",
                "tonejs@14.8.49",
                "c2.min.js@1.0.0",
                "chromajs@2.4.2",
                "p5.grain.js@0.6.1",
                "svgjs@3.1.2",
                "aframejs@1.2.0",
                "babylonjs@5.47.0",
                "paperjs@0.12.17",
                "regljs@2.1.0"
            ]

## Launch your art on Bitcoin

Upload your project at https://generative.xyz/create
